package ui;
import java.util.*;
import model.Student;
import service.StudentService;
import service.StudentServiceImpl;

import java.util.*;

import Exception.DataNotPresentException;
public class StudentMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner s=new Scanner(System.in);
		
		Student s1 = new Student(1,"Sachin","Ranchi");
		Student s2 = new Student(2,"Dhoni","Ranchi");
		Student s3 = new Student(3,"KapilDev","Chandigarh");
		Student s4 = new Student(4,"Virat Kohli","New Delhi");
		Student s5 = new Student(6,"Rohit Sharma","New Delhi");
		Student s6 = new Student(7,"Irfan Pathan","Ahmedabad");
		
		List<Student> list=new ArrayList<Student>();
		
		list.add(s1);
		list.add(s2);
		list.add(s3);
		list.add(s4);
		list.add(s5);
		list.add(s6);
		
		// creating obj for service layer
		
		StudentService service=new StudentServiceImpl();
		for(Student fromlist:list) {
			try {
				System.out.println(service.addStudent(fromlist));
			} catch (DataNotPresentException e) {
				System.out.println(e.getMessage());
			}
		}
		
		
		//reading
	
		try {
		System.out.println(service.readStudent());
		}
		catch(DataNotPresentException e) {
			System.out.println(e.getMessage());
		}

		System.out.println("enter the city");
		String citydata=s.nextLine();
		
		
		try {
		
		System.out.println(service.getByCity(citydata));
		}
		catch(DataNotPresentException e) {
			System.out.println(e.getMessage());
		}
//		List<Student> stuList= seervice.getCity("Mumbai");
//		System.out.println(stuList);
		
		
		System.out.println("enter ID to display details");
		int id=s.nextInt();
		
		 
		System.out.println(service.searchId(id));
		
		
		
		System.out.println("sorted by name");
		Collections.sort(list,Comparator.comparing(Student::getName));
		System.out.println(list);
		
		System.out.println("sorted by ID");
		Collections.sort(list,Comparator.comparing(Student::getId));
		System.out.println(list);
		
		
	}

}
