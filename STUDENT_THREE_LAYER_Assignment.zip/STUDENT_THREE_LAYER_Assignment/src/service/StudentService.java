package service;

import java.util.List;

import Exception.DataNotPresentException;
import model.Student;

public interface StudentService {
	
	public String addStudent(Student student)throws DataNotPresentException;
	
	public  List<Student> readStudent()throws DataNotPresentException;
	
	public List<Student> getByCity(String city) throws DataNotPresentException ;
	
	public List<Student> searchId(int id); 
	
 
}
