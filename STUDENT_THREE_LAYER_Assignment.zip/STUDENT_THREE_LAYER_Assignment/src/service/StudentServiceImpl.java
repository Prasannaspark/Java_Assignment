package service;
import Exception.DataNotPresentException;
import java.util.List;

import Exception.DataNotPresentException;

import dao.StudentDAO;
import dao.StudentDAOImpl;
import model.Student;

public class StudentServiceImpl implements StudentService {
	StudentDAO studentDAO = new StudentDAOImpl();

	@Override
	public String addStudent(Student student) throws DataNotPresentException {
		// TODO Auto-generated method stub

		String message = studentDAO.addStudent(student);

		return message;
	}

	@Override
	public List<Student> readStudent() throws DataNotPresentException {
		List<Student> read = studentDAO.readStudent();

		return read;
	}

	@Override
	public List<Student> getByCity(String city)  throws DataNotPresentException  {
		List<Student> citystore= studentDAO.getByCity(city);
		
		return citystore;
	}
	
	@Override
	public List<Student> searchId(int id) {
		List<Student> findid=studentDAO.searchId(id);
		return findid;
	}

}
