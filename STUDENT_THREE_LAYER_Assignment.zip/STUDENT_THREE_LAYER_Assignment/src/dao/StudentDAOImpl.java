package dao;

import Exception.DataNotPresentException;
import model.Student;
import java.util.*;

import Exception.DataNotPresentException;

public class StudentDAOImpl implements StudentDAO {
	private List<Student> studentlist = new ArrayList<Student>();

	@Override
	public String addStudent(Student student) throws DataNotPresentException {

		// need a collection to store a student data
		if (student != null) {
			studentlist.add(student);
			return "student id " + student.getId() + "is added Succesfully";

		} else {

			throw new DataNotPresentException("data not present");

		}
	}

	@Override
	public List<Student> readStudent() throws DataNotPresentException {
		// TODO Auto-generated method stub
		if (!studentlist.isEmpty()) {
			/*
			 * for(Student readall:studentlist) { return readall; }
			 */
			return studentlist;
		} else {
			throw new DataNotPresentException("data not present");
		}

	}

	@Override
	public List<Student> getByCity(String city) throws DataNotPresentException {
		// TODO Auto-generated method stub
		List<Student> samecity = new ArrayList<Student>();

		for (Student citymatch : studentlist) {

			if (citymatch.getCity().equals(city)) {

				samecity.add(citymatch);
			}

		}

		if (!samecity.isEmpty()) {
			return samecity;
		}

		else {
			throw new DataNotPresentException("data not present");
		}

	}
	
@Override
public List<Student> searchId(int id) {
	// TODO Auto-generated method stub
	List<Student> iddetails=new ArrayList<Student>();
	
	for(Student data:studentlist)
	if(data.getId()==id) {
		
		iddetails.add(data);
		
	}
	
	return iddetails;
}

}
